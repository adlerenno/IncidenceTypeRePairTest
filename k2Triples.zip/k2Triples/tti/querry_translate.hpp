/* Headerfile to make querry_translate a objekt so I can merge all Programms
*/
#pragma once
int querry_translate(int argc, char* argv[]);