
/*
Hashmap, welche dem Namen eines Eintrags in Rdfdateien im .nq vorat in eine Zahl übersetzt.
currently unoptimized 
*/
#include "index.h"


void save(std::vector<std::string> ind, const std::string to)
{
    FILE *f = fopen(to.c_str(), "w");

    for(std::string i:ind){
        fprintf(f,"%s\n",i.c_str());
    }
    //do something
    fclose(f);
}


void destroyIndex(std::vector<std::string> ind)
{   
    ind.clear();
}

std::vector<std::string> load(std::string from)
{
    std::ifstream f;
    f.open(from);
    std::vector<std::string> out;
    std::string s;
    //char* buf;
    int i = 1;
    while(std::getline(f,s)){
        out.push_back(s);
        s="";
    }
    //std::cout << &buf<<"\n";
    f.close();
    return out;
}

