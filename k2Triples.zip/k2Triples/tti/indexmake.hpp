/* Headerfile to make indexmake a objekt so I can merge all Programms
*/
#pragma once

int indexmake(int argc, char* argv[]);