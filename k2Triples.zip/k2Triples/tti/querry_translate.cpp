#include <cstring>
#include <string>
#include "index.h"
#include <vector>
#include <stdio.h>
#include <memory>
#include <stdlib.h>
#include <unordered_set>
#include <iostream>
#include <sstream>
#include <fstream>
#include <array>
int test;

int main2 (int argc, char* argv[]){
    if(argc<7){
		fprintf(stderr,"Erwartet: %s <Plaintextquerrys> <Outputfilename> <DiccP> <DiccSO> <DiccS> <DiccO>\n",argv[0]);
		return(-1);
	}

    std::ifstream fQuery(argv[1]);
    if(fQuery.is_open()){
        std::cout << "opened: "<< argv[1]<<"\n";
    }else{
        std::cerr << argv[1] <<"File could not be opend\n";
        return -1;
    }
    
    std::ofstream fQueryout;
    fQueryout.open(argv[2]);
    
    //if (-1 == fQuery) {
	//	fprintf(stdout, "Konnte die folgende Datei nicht lesen %s \n", argv[1]);
	//	return -1;
	//}
    //if (-1 == fQueryout= fopen(argv[3], "w")) {
	//	fprintf(stdout, "Konnte auf die folgende Datei nicht schreiben%s \n", argv[3]);
	//	return -1;
	//}
     std::cout << "opened: "<< argv[2]<<"\n";

    std::vector<std::string> vec =load(argv[3]);
    std::unordered_map<std::string,int> mapP;
    int i = 1;
    std::cout << "DiccP read\n";
    for (std::string element : vec){
        mapP.insert(std::make_pair(element,i));
        i++;
    }
    std::cout << "size: "<< vec.size()<<"\n";
    //int numpreds= i;
    i=1;
    std::cout << "DiccP created\n";
    std::vector<std::string> vec2 = load(argv[4]);
    std::cout << "DiccSO read\n";
    std::unordered_map<std::string,int> mapSO;
    int j = 1024;
    for (std::string element : vec2){
        //if(i==j){
        //    std::cout << i<<" entries read\n";
        //    j*=2;
        //}
        mapSO.insert(std::make_pair(element,i));
        i++;
    }
    std::cout << i<<" entries read\n";
    int sizeSO=i;
    i=1;
    std::cout << "DiccSO created\n";
    std::vector<std::string> vec3 = load(argv[5]);
    std::cout << "DiccS read\n";
    std::unordered_map<std::string,int> mapS;
    for (std::string element : vec3){
        mapS.insert(std::make_pair(element,i));
        i++;
    }
    std::cout << "DiccS created\n";
    std::vector<std::string> vec4 = load(argv[6]);
    std::cout << "DiccO read\n";
    std::unordered_map<std::string,int> mapO;
    i = 1;
    for (std::string element : vec4){
        mapO.insert(std::make_pair(element,i));
        i++;
    }
    i=0;
    std::cout << "Dicc's read\n";
    unsigned int nQueries =0;
    std::string line;
    std::getline(fQuery, line);
    std::istringstream linestream(line);
    linestream >> nQueries;
    fQueryout << nQueries <<"\n";
    int querrytype;
    std::cout << nQueries <<" here\n";
    for(unsigned int k=1 ;k<=nQueries;k++){
        std::string loopline;
        std::string Subjekt;
        std::string Praedikart;
        std::string Objekt;
        std::getline(fQuery, loopline);
        if(loopline.empty()){
            std::cerr << "Format error in line " << k+1<<"\n";
            continue;
        }
        std::istringstream looplinestream(loopline);
        looplinestream >> Subjekt;
        looplinestream >> Praedikart; 
        looplinestream >> Objekt;
        std::cout << Subjekt <<" "<< Praedikart<<" "<<Objekt<< " was read\n";
        int indexS=0;
        int indexP=0;
        int indexO=0;
        querrytype = 0;
        if(std::strcmp(Subjekt.c_str(), "?")==0){
            querrytype +=1;
        }else{
            if(mapSO.contains(Subjekt)){
                indexS = mapSO[Subjekt]-1;
            }else{
                indexS = sizeSO + mapS[Subjekt]-1;
            }
        }
        if(std::strcmp(Praedikart.c_str(),"?")==0){
            querrytype +=2;
        } else{
            indexP = mapP[Praedikart];
        }
        if(std::strcmp(Objekt.c_str(), "?")==0){
            querrytype +=4;
        }else{
            if(mapSO.contains(Objekt)){
                indexO = mapSO[Objekt]-1;
            }else{
                indexO = sizeSO + mapS[Objekt]-1;
            }
        }

        switch (querrytype){
            case 0: fQueryout << 1 <<" " <<indexS<< " "<< indexP<< " "<< indexO<< "\n";
            std::cout << 1 <<" " <<indexS<< " "<< indexP<< " "<< indexO<<" was written in "<<k<<" \n";
            break;
            case 1: fQueryout << 4 <<" " <<indexS<< " "<< indexP<< " "<< indexO<< "\n";
            break;
            case 2: fQueryout << 2 <<" " <<indexS<< " "<< indexP<< " "<< indexO<< "\n";
            break;
            case 3: fQueryout << 5 <<" " <<indexS<< " "<< indexP<< " "<< indexO<< "\n";
            break;
            case 4: fQueryout << 3 <<" " <<indexS<< " "<< indexP<< " "<< indexO<< "\n";
            break;
            case 5: fQueryout << 6 <<" " <<indexS<< " "<< indexP<< " "<< indexO<< "\n";
            break;
            case 6: fQueryout << 7 <<" " <<indexS<< " "<< indexP<< " "<< indexO<< "\n";
            break;
            case 7: std::cerr << "Invalid querry in line "<< i+1 <<"\n";
            break;
            default:
            break;
        }
        
        if(k == nQueries){
            std::cout << "Here\n";
            fQuery.close();
            fQueryout.close();
            std::cout << "Translation finnished\n";
            return 0;
        }
    }
    //std::cout << "Translation finnished\n";
    fQuery.close();
    fQueryout.close();
    std::cout << "Translation finnished\n";
    return 0;
}
int querry_translate(int argc, char *argv[])
{
    return main2(argc, argv);
}