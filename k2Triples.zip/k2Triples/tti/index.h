/*
Hashmap, welche dem Namen eines Eintrags in Rdfdateien im .nq vorat in eine Zahl übersetzt.
currently unoptimized 
*/
#include <unordered_map>
#include <string>
#include <iostream>
#include <vector>
#include "iterator"
#include <cstring>
#include <unistd.h>
#include <iostream>
#include <sstream>
#include <fstream>

const int READSIZE =512;// igendwas zwischen 0 und pagesize wahrscheinlich 4096


std::vector<std::string> load (std::string from); // lade Hashmap aus Datei


void save (std::vector<std::string> ind, std::string to);// speichere Hashmap in Datei

//long get (std::vector<std::string> ind,std::string name); // übersetzt den Namen in den dazugehörigen Index

//std::string invget (std::vector<std::string> ind,long i);// übersetzt Index in den dazugehörigen Namen

void destroyIndex(std::vector<std::string> ind); //free memory