#include "indexmake.hpp"
#include <cstring>
#include <string>
#include "index.h"
#include <vector>
#include <memory>
#include <stdlib.h>
#include <unordered_set>
#include <array>
const int TESTSIZE =1000;
const bool TESTMODE = false;
//const int READSIZE =512;
int main1 (int argc, char* argv[]){
    if(argc<3){
		std::cerr<<"Erwartet: "<<argv[0]<<" <Inputfile> <Outputfilename>\n";
		return(-1);
	}
    long max = 0;
    if(argc>3){
        max = atoi(argv[3]);
        std::cout << "max: " << max <<"\n";
    }
    //FILE * readfrom = fopen(argv[1],"r");
    //FILE * res = fopen(filename2,"w");
    //free(filename2);

    //char buf[READSIZE];
    //fread(&buf[0], sizeof( char), READSIZE,readfrom);
    std::ifstream readfile;
    readfile.open(argv[1]);
    bool inqoute = false;
    bool wasbs =false;
    std::string S = "";
    std::string P = "";
    std::string O = "";
    std::string line;
    int PSOcount = 0;
    int omg=1048576;
    std::unordered_set<std::string> setS ;
    std::unordered_set<std::string> setO ;
    std::unordered_set<std::string> setP ;
    //std::unordered_set<std::string> setSO ; braucht man nicht
    std::vector<std::string> vecS;
    std::vector<std::string> vecO;
    std::vector<std::string> vecP;
    std::vector<std::string> vecSO; 
    uint_fast8_t state = 0;
    //fprintf(stdout,"Here I Read %s\n","Hello4");
    //fprintf(stdout,"Here I Read %C\n",buf[0]);
    bool run=true;
    while (std::getline(readfile, line))
    {
        //std::cout << line <<"\n";
        //fprintf(stdout,"Here I Read %C\n",buf[1]);
        for (int i = 0; i<line.length();i++){
            if(line[i]==EOF){
                goto endofread;
            }
            if (line[i]==' '&&!inqoute){
                //fprintf(stdout,"Here I Read %s\n","Hello");
                state++; 
            }else{
                if (line[i]=='"'&&!wasbs){
                    wasbs = false;
                    inqoute = !inqoute;    
                }
                if(line[i]=='\n'){
                    inqoute = false;
                    //fprintf(stdout,"Here I Read %s %s %s\n",S.c_str(),P.c_str(),O.c_str());
                    if (S[0]== '#'){// Ignorier Kommentare 
                        S.clear();
                        O.clear();
                        P.clear(); 
                        state = 0;
                        continue;
                    }
                    //hier wird auf die dits geschrieben. 
                    if (S.empty()||O.empty()||P.empty()){
                        //std::cout << S <<",, "<<O<<",, "<<P<<"\n";
                        std::cout <<"PSOcount:"<<PSOcount<<"\n";
                        S.clear();
                        O.clear();
                        P.clear();
                        goto endofread;
                    }

                    //teil P
                    if(!(setP.contains(P))){
                        vecP.push_back(P);
                        setP.insert(P);
                    }

                    //teil S
                    if(!(setS.contains(S))){
                        if(setO.contains(S)){
                            vecSO.push_back(S);
                            setS.insert(S);
                        }else{
                            vecS.push_back(S);
                            setS.insert(S);
                        }
                    }
                    //teil O
                    if(!(setO.contains(O))){
                        if(setS.contains(O)){
                            vecSO.push_back(O);
                            setO.insert(O);
                        }else{
                            vecO.push_back(O);
                            setO.insert(O);
                        }
                    }
                    PSOcount++;//PSOtriple.push_back({P,S,O});
                    if(PSOcount == max){
                        for (int i3000 = 0; i3000<READSIZE;i3000++){
                        std::cout << line[i3000] ;
                        }
                        std::cout <<"\n";
                        goto endofread;
                    }
                    //ausgabe von Anzahl der bisher eingelesenen Tripel pro binärer Gößenordnung ab 2^20 = 1048576
                    if(PSOcount==omg){
                        std::cout <<omg<<" triples read\n";
                        omg *= 2;
                    }
                    S.clear();
                    O.clear();
                    P.clear(); 
                    state = 0;

                    //temporaer
                    if(vecS.size()<TESTSIZE&&TESTMODE){
                        //temp printer
                        std::cout << "SO: ";
                        for (auto i5000: vecSO){
                            std::cout << i5000 << ' ';
                        }
                        std::cout << '\n';

                        std::cout << "O: ";
                        for (auto i5001: vecO){
                            std::cout << i5001 << ' ';
                        }
                        std::cout << '\n';

                        std::cout << "S: ";
                        for (auto i5002: vecS){
                            std::cout << i5002 << ' ';
                        }
                        std::cout << '\n';

                        std::cout << "P: ";
                        for (auto i5003: vecP){
                            std::cout << i5003 << ' ';
                        }
                        std::cout << '\n';
                        return 0;
                    }
                    continue;
                }   
                else{
                    switch(state){
                        case 0: S+=line[i]; break;
                        case 1: P+=line[i]; break;
                        case 2: O+=line[i]; break;
                    }
                }
            }
            if(line[i]=='\\' ){
                wasbs =true;
            }else{
                if(wasbs){
                    wasbs =false;    
                }
            }
        }
        inqoute = false;
                    //fprintf(stdout,"Here I Read %s %s %s\n",S.c_str(),P.c_str(),O.c_str());
                    if (S[0]== '#'){// Ignorier Kommentare 
                        S.clear();
                        O.clear();
                        P.clear(); 
                        state = 0;
                        continue;
                    }
                    //hier wird auf die dits geschrieben. 
                    if (S.empty()||O.empty()||P.empty()){
                        //std::cout << S <<",, "<<O<<",, "<<P<<"\n";
                        std::cout <<"PSOcount:"<<PSOcount<<"\n";
                        S.clear();
                        O.clear();
                        P.clear();
                        goto endofread;
                    }

                    //teil P
                    if(!(setP.contains(P))){
                        vecP.push_back(P);
                        setP.insert(P);
                    }

                    //teil S
                    if(!(setS.contains(S))){
                        if(setO.contains(S)){
                            vecSO.push_back(S);
                            setS.insert(S);
                        }else{
                            vecS.push_back(S);
                            setS.insert(S);
                        }
                    }
                    //teil O
                    if(!(setO.contains(O))){
                        if(setS.contains(O)){
                            vecSO.push_back(O);
                            setO.insert(O);
                        }else{
                            vecO.push_back(O);
                            setO.insert(O);
                        }
                    }
                    PSOcount++;//PSOtriple.push_back({P,S,O});
                    if(PSOcount == max){
                        for (int i3000 = 0; i3000<READSIZE;i3000++){
                        std::cout << line[i3000] ;
                        }
                        std::cout <<"\n";
                        goto endofread;
                    }
                    //ausgabe von Anzahl der bisher eingelesenen Tripel pro binärer Gößenordnung ab 2^20 = 1048576
                    if(PSOcount==omg){
                        std::cout <<omg<<" triples read\n";
                        omg *= 2;
                    }
                    S.clear();
                    O.clear();
                    P.clear(); 
                    state = 0;
        
        
        //fprintf(stdout,"%s\n",S.c_str());

        //fread(&buf[0], sizeof buf[0], 4,readfrom);
        //fprintf(stdout,"Here I Read %C\n",buf[0]);
        //return(1);
        //fread(&buf[0], sizeof( char), READSIZE,readfrom);
    }
    endofread:
    readfile.close();
    //fclose(readfrom);
    
    //write diccP
    std::unordered_map<std::string,long> mapP;
    long i2000 = 0;
    for(std::string e : vecP){
        mapP.insert(std::make_pair(e,i2000));
        i2000++;
    }
    std::string outname =argv[2];
    std::string outfilename =outname+"DiccP.txt";
    save(vecP,outfilename);
    std::cout << "diccP File created with size "<<vecP.size() <<" entries\n";
    setP.clear();
    std::unordered_map<std::string,long> mapSO;
    long cSO=0;
    for(std::string e : vecSO){
        mapSO.insert(std::make_pair(e,cSO));
        cSO++;
    }
    outfilename =outname+"DiccSO.txt";
    save(vecSO,outfilename);
    std::cout << "diccSO file created with size "<< vecSO.size() <<" entries\n";

    std::unordered_map<std::string,long> mapS;
    i2000=0;
    long j=0;
    for(std::string e : vecS){
        if(!setO.contains(e)){
            if(i2000!=j){
                vecS[i2000]=vecS[j];
            }
            mapS.insert(std::make_pair(e,i2000));
            i2000++;
        }
        j++;
    }
    vecS.resize(i2000);
    outfilename =outname+"DiccS.txt";
    save(vecS,outfilename);
    std::cout << "diccS file created with size "<< vecS.size() <<" entries\n";


    std::unordered_map<std::string,long> mapO;
    i2000=0;
    j=0;
    for(std::string e : vecO){
        if(!setS.contains(e)){
            if(i2000!=j){
                vecO[i2000]=vecO[j];
            }
            mapO.insert(std::make_pair(e,i2000));
            i2000++;
        }
        j++;
    }
    vecO.resize(i2000);
    outfilename =outname+"DiccO.txt";
    save(vecO,outfilename);
    std::cout << "diccO file created with size "<< vecO.size() <<" entries\n";

    uint* out =(uint*) malloc(sizeof(uint)*3*PSOcount);
    i2000=0;


    readfile.open(argv[1]);
    //readfrom = fopen(argv[1],"r");
    //fread(&buf[0], sizeof( char), READSIZE,readfrom);

    std::cout << "Start second file read\n";
    int omg2 = 1048576;
    int ct=0;
    state = 0;
    inqoute = false;
    wasbs =false;
    while (std::getline(readfile, line))
    {
        //std::cout << "Here in second read\n";
        //fprintf(stdout,"Here I Read %C\n",buf[1]);
        for (int i2 = 0; i2<line.size();i2++){
            if(line[i2]==EOF){
                goto endofread2; // to break out ogf nested loop
            }
            if (line[i2]==' '&&!inqoute){
                //fprintf(stdout,"Here I Read %s\n","Hello");
                state++; 
            }else{
                if (line[i2]=='"'&&!wasbs){
                    inqoute = !inqoute;    
                }
                if(line[i2]=='\n'){
                    inqoute = false;
                    if (S[0]== '#'){// Ignorier Kommentare 
                        S.clear();
                        O.clear();
                        P.clear(); 
                        state = 0;
                        continue;
                    }
                    //hier wird auf die dits geschrieben. 
                    if (S.empty()||O.empty()||P.empty()){
                        std::cout <<"Triple count:"<<PSOcount<<"\n";
                        goto endofread2;
                    }
                    if(ct==omg2){
                        std::cout <<omg2<<" triples read\n";
                        omg2 *= 2;
                    }

                    out[i2000]=mapP[P]+1;
                    i2000++;
                    if(setO.contains(S)){
                        out[i2000] =  mapSO[S]+1;// should not use 0 start counting from 1
                    }else{
                        out[i2000] = vecSO.size()+mapS[S]+1;
                    }
                    i2000++;
                    if(setS.contains(O)){
                        out[i2000] = mapSO[O]+1;
                    }else{
                        out[i2000] = vecSO.size()+mapO[O]+1;
                    }
                    i2000++;
                    if (ct <10&&TESTMODE){
                        std::cout <<  setO.contains(S) << " " << setS.contains(O) << "\n";
                        std::cout << "S,O: " <<  S << " "<< P << " " << O << "\n";
                        std::cout << "setS,setO Size: " <<  setO.size() << " " << setS.size() << "\n";
                    }
                    S.clear();
                    O.clear();
                    P.clear(); 
                    state = 0;
                    ct++;
                    if(ct == max){
                        goto endofread2;
                    }
                    continue;
                }   
                else{
                    switch(state){
                        case 0: S+=line[i2]; break;
                        case 1: P+=line[i2]; break;
                        case 2: O+=line[i2]; break;
                    }
                }
                
            }
            if(line[i2]=='\\' ){
                wasbs =true;
            }else{if(wasbs){
                    wasbs =false;    
                }
            }
        }
                inqoute = false;
                if (S[0]== '#'){// Ignorier Kommentare 
                    S.clear();
                    O.clear();
                    P.clear(); 
                    state = 0;
                    continue;
                }
                //hier wird auf die dits geschrieben. 
                if (S.empty()||O.empty()||P.empty()){
                    std::cout <<"Triple count:"<<PSOcount<<"\n";
                    goto endofread2;
                }
                if(ct==omg2){
                    std::cout <<omg2<<" triples read\n";
                    omg2 *= 2;
                }

                out[i2000]=mapP[P]+1;
                i2000++;
                if(setO.contains(S)){
                    out[i2000] =  mapSO[S]+1;// should not use 0 start counting from 1
                }else{
                    out[i2000] = vecSO.size()+mapS[S]+1;
                }
                i2000++;
                if(setS.contains(O)){
                    out[i2000] = mapSO[O]+1;
                }else{
                    out[i2000] = vecSO.size()+mapO[O]+1;
                }
                i2000++;
                if (ct <10&&TESTMODE){
                    std::cout <<  setO.contains(S) << " " << setS.contains(O) << "\n";
                    std::cout << "S,O: " <<  S << " "<< P << " " << O << "\n";
                    std::cout << "setS,setO Size: " <<  setO.size() << " " << setS.size() << "\n";
                }
                S.clear();
                O.clear();
                P.clear(); 
                state = 0;
                ct++;
                if(ct == max){
                    goto endofread2;
                }
                continue;
            
        //fread(&buf[0], sizeof( char), READSIZE,readfrom);
    }
    endofread2:
    //fclose(readfrom);
    readfile.close();
    std::cout << "Binary calculated\n";
    //write binary to file
    std::string file =argv[2];
    file.append(".hdt.triples");
    FILE * f =fopen(file.c_str(),"w");
    fwrite(out,sizeof(uint),3*PSOcount,f);
    fclose(f);
    free(out);
    //delete[] buf;

    mapSO.clear();
    mapS.clear();
    mapP.clear();
    mapO.clear();

    setS.clear();
    setO.clear();

    vecSO.clear();
    vecSO.shrink_to_fit();
    vecS.clear();
    vecS.shrink_to_fit();
    vecP.clear();
    vecP.shrink_to_fit();
    vecO.clear();
    vecO.shrink_to_fit();
    //free(out);
    std::cout << "The output has been writen to \""<<file <<"\"\n";
    std::cout << "Finished\n";
    return 0;
}


int indexmake(int argc, char *argv[]){
    return main1(argc, argv);
}