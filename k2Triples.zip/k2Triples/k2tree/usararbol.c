#include <stdio.h>
#include <math.h>
#include <string.h>
#include "man_kTree.h"
#include "man_rdfSimpleQueries.h"


int main8(int argc, char* argv[]) {
	int i;
	FILE *fQuery;
	int * queries, *sujetos, *objetos, *predicados;
	if (argc < 3) {
		fprintf(stderr, "USAGE: %s <GRAPH> <nPred> <queryFile>\n", argv[0]);
		return (-1);
	}

	int numPredicados = atoi(argv[2]);

	TREP ** treps = (TREP *) malloc(sizeof(TREP) * numPredicados);

	char nomFich[256];

	for (i = 1; i <= numPredicados; i++) {
		sprintf(nomFich, "%s%d", argv[1], i);// man: .txt ist weg
		treps[i] = loadTreeRepresentation(nomFich);
	}

	/**************************************************/
	/*                  LECTURA QUERIES  			  */
	/**************************************************/
	if (-1 == (fQuery = fopen(argv[3], "r"))) {
		fprintf(stdout, "ERROR: no se ha podido leer el fichero %s", argv[3]);
		return 1;
	}
	int nQueries, sujeto, predicado, objeto;
	fscanf(fQuery, "%d\n", &nQueries);
	sujetos = (int *) malloc(sizeof(int) * nQueries);
	objetos = (int *) malloc(sizeof(int) * nQueries);
	predicados = (int *) malloc(sizeof(int) * nQueries);
	queries = (int *) malloc(sizeof(int) * nQueries);

	for (i = 0; i < nQueries; i++) {
		if (-1 == fscanf(fQuery, "%d %d %d %d\n", &(queries[i]), &(sujetos[i]),
				&(predicados[i]), &(objetos[i]))) {
			fprintf(stderr, "ERROR: formato erroneo del archivo de queries");
		}
	}
	fclose(fQuery);
	/***************************************************/

	for (i = 0;i < nQueries; i++){
		switch (queries[i]) {
		  case 1:  operacion1(treps,sujetos[i],predicados[i],objetos[i]);
				   continue;
		  case 2:  operacion2(treps,sujetos[i],objetos[i],numPredicados);
		  	  	   continue;
		  case 3:  operacion3(treps,sujetos[i],predicados[i]);
		  	  	   continue;
		  case 4:  operacion4(treps,predicados[i], objetos[i]);
		  	  	   continue;
		  case 5:  operacion5(treps,objetos[i],numPredicados);
		  	  	   continue;
		  case 6:  operacion6(treps,predicados[i]);
		  	  	   continue;
		  case 7:  operacion7(treps,sujetos[i],numPredicados);
		  default: continue;
		}
	}
	  // <S,P,O>
	     int operacion1(TREP ** treps,int sujeto, int predicado, int objeto);

	     // <S,P?,O>
	     int operacion2(TREP ** treps,int sujeto, int objeto, int nPreds);

	     // <S,P,O?>
	     int operacion3(TREP ** treps,int sujeto, int predicado);

	     // <S?,P,O>
	     int operacion4(TREP ** treps, int predicado, int objeto);

	     // <S?,P?,O>
	     int operacion5(TREP ** treps,int objeto, int nPreds);

	     // <S?,P,O?>
	     int operacion6(TREP ** treps,int predicado);

	     // <S,P?,O?>
	     int operacion7(TREP ** treps,int sujeto, int nPreds);


	for (i=1;i<= numPredicados;i++)
		destroyTreeRepresentation(treps[i]);

	return 0;
}
int use_tree(int argc, char* argv[])
{
    return main8(argc, argv);
}