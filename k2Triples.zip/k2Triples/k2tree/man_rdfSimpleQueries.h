#pragma once
#ifndef OPERACIONESINCLUDED
#define OPERACIONESINCLUDED
#include "man_kTree.h"

     // <S,P,O>
     int operacion1(TREP ** treps,int sujeto, int predicado, int objeto);

     // <S,P?,O>
     int operacion2(TREP ** treps,int sujeto, int objeto, int nPreds);

     // <S,P,O?>
     int operacion3(TREP ** treps,int sujeto, int predicado);

     // <S?,P,O>
     int operacion4(TREP ** treps, int predicado, int objeto);

     // <S?,P?,O>
     int operacion5(TREP ** treps,int objeto, int nPreds);

     // <S?,P,O?>
     int operacion6(TREP ** treps,int predicado);

     // <S,P?,O?>
     int operacion7(TREP ** treps,int sujeto, int nPreds);

#endif
