/* Headerfile to make recuperararbol a objekt so i can merge all Programms
*/
#pragma once
int rebuild_tree(int argc, char* argv[]);