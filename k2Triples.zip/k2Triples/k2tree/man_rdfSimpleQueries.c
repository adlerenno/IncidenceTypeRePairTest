#include "man_rdfSimpleQueries.h"

  // <S,P,O>
  int operacion1(TREP ** treps,int sujeto, int predicado, int objeto){
	  fprintf(stdout,"Query 1:<%d,%d,%d>\n",sujeto,predicado,objeto);
	  if (compactTreeCheckLinkQuery(treps[predicado],sujeto,objeto))
		  fprintf(stdout,"<%d,%d,%d>\n",sujeto,predicado,objeto);
	  else
		  fprintf(stdout,"-----------\n");
	  return 0;
  }

  // <S,P?,O>
  int operacion2(TREP ** treps,int sujeto,int objeto,int nPreds){
	  fprintf(stdout,"Query 2:<%d,?,%d>\n",sujeto,objeto);
	  int i;
	  for (i=0;i<=nPreds;i++){
		  if (compactTreeCheckLinkQuery(treps[i],sujeto,objeto))
			  fprintf(stdout,"<%d,%d,%d>\n",sujeto,i,objeto);
	  }
	  return 0;
  }

  // <S,P,O?>
  int operacion3(TREP ** treps, int sujeto, int predicado){
	  int i;
	  fprintf(stdout,"Query 3:<%d,%d,?>\n",sujeto,predicado);
	  int * x = compactTreeAdjacencyList(treps[predicado],sujeto);
	  for (i=0;i<x[0];i++){
		  fprintf(stdout,"<%d,%d,%d>",sujeto,predicado,x[i+1]);
	  }
	  return 0;
  }

  // <S?,P,O>
  int operacion4(TREP ** treps, int predicado, int objeto){
	  int i;
	  fprintf(stdout,"Query 4:<?,%d,%d>\n",predicado,objeto);
	  int * x = compactTreeInverseList(treps[predicado],objeto);
	  for (i=0;i<x[0];i++){
	    fprintf(stdout,"<%d,%d,%d>",x[i+1],predicado,objeto);
	  }
	  return 0;
  }

  // <S?,P?,O>
  int operacion5(TREP ** treps,int objeto, int nPreds){
	  int i,j;
	  fprintf(stdout,"Query 5: <?,?,%d>\n",objeto);
	  int * x;
	  for (i=1;i<=nPreds;i++){
		  x=compactTreeInverseList(treps[i],objeto);
		  for (j=0;j<x[0];j++)
			  fprintf(stdout,"<%d,%d,%d>",x[j+1],i,objeto);
	  }
	  return 0;
  }

  // <S?,P,O?>
  int operacion6(TREP ** treps,int predicado){



	  return 0;
  }

  // <S,P?,O?>
  int operacion7(TREP ** treps,int sujeto, int nPreds){
	  int i,j;
	  fprintf(stdout,"Query 7: <%d,?,?>\n",sujeto);
	  int * x;
	  for (i=1;i<=nPreds;i++){
		  x=compactTreeAdjacencyList(treps[i],sujeto);
		  for (j=0;j<x[0];j++)
			  fprintf(stdout,"<%d,%d,%d>",sujeto,i,x[j+1]);
	  }
	  return 0;
  }






