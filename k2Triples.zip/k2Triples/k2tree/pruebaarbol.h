/* Headerfile to make pruebaarbol a objekt so i can merge all Programms
*/
#pragma once
int build_tree(int argc, char* argv[]);