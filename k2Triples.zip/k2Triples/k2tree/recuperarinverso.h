/* Headerfile to make recuperarinverso a objekt so i can merge all Programms
*/
#pragma once
int invrebuild_tree(int argc, char* argv[]);