/* Headerfile to make tiemposarbol a objekt so i can merge all Programms
*/
#pragma once
int test_tree(int argc, char* argv[]);