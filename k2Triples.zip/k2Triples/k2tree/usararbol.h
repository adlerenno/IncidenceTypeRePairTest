/* Headerfile to make usararbol a objekt so i can merge all Programms
*/
#pragma once
int use_tree(int argc, char* argv[]);