/* Headerfile to make tiemposinverso a objekt so i can merge all Programms
*/
#pragma once
int revtest_tree(int argc, char* argv[]);