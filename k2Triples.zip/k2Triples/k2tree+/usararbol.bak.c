#include <stdio.h>
#include <math.h>
#include <string.h>
#include "kTree.h"
#include <sys/time.h>
#include <time.h>
#include "directcodesI.h"
#include "commons.h"
#include "simplePatterns.h"
#define SEC_TIME_DIVIDER  ((double) 1.0    )     //1 sec = 1 sec
#define SEC_TIME_UNIT       "sec"


int main(int argc, char* argv[]) {
	int i,k;
	struct timeval tv1, tv2;
	FILE * queries;
	int * queriesDat[4];
	int tipoQuery;

	if (argc < 9) {
		fprintf(
				stderr,
				"USAGE: %s <GRAPH> <nPred> <queries> <nQueries> <dacCodeS> <dacCodeO> <|SO|> <tipoQuery> [iter]\n",
				argv[0]);
		return (-1);
	}

	inicializaMemoria();

	int numSO=atoi(argv[7]);
	tipoQuery = atoi(argv[8]);
	int numPredicados = atoi(argv[2]);
	int numQueries = atoi(argv[4]);
	fprintf(stderr,"numpredicados: %d\n",numPredicados);
	fprintf(stderr,"num queries:%d\n",numQueries);
	int numIteraciones=1;

	if (argc==10){
		numIteraciones=atoi(argv[9]);
		fprintf(stderr,"Iteraciones:%d\n",numIteraciones);
	}
	else numIteraciones=1;
	fprintf(stderr,"Indice SP:\n");	
	long memoriaAntes=getMemoria();
	INDICEDAC * indiceSP = cargarDAC(argv[5],numPredicados);
	long memoriaDespues=getMemoria();
	fprintf(stderr,"%ld bytes\n",memoriaDespues-memoriaAntes);
	memoriaAntes=memoriaDespues;
	fprintf(stderr,"Indice OP\n");
	INDICEDAC * indiceOP = cargarDAC(argv[6],numPredicados);
	memoriaDespues=getMemoria();
	fprintf(stderr,"%ld bytes\n",memoriaDespues-memoriaAntes);
	inicializarEstructuras(numPredicados, numSO);
	
	int numS=0;
	long acumulacion=0;
	for (numS=0;numS<65200769;numS++){
	  obtenerPredicados(*indiceOP,numS);
	  acumulacion+=resDAC.numeroPredicados;
	}

	for (i = 0; i < 4; i++) {
		queriesDat[i] = (int *) malloc(sizeof(int) * numQueries);
	}

	if ((queries = fopen(argv[3], "r")) == NULL) {
		fprintf(stderr, "error: no se pudo abrir el fichero %s\n", argv[3]);
		return 1;
	} else {
		fprintf(stderr, "%s\n", argv[3]);
	}


	
	for (i = 0; i < numQueries; i++){
		if (-1==fscanf(queries,"%d;%d;%d;%d\n",  &queriesDat[0][i],&queriesDat[1][i],
				&queriesDat[2][i],&queriesDat[3][i])){
			fprintf(stderr,"error al leer queries\n");exit(1);
		}
	}

	TREP ** treps = (TREP **) mymalloc(sizeof(TREP *) * (numPredicados+1));

	char nomFich[256];

	fprintf(stderr,"Predicados\n");
	long ini=getMemoria();
	for (i = 1; i <= numPredicados; i++) {
		
	//	if (!(i%100))fprintf(stderr,"%d\n",i);
		sprintf(nomFich, "%s%d.txt", argv[1], i);
		treps[i] = loadTreeRepresentation(nomFich);
	}
	int totalAristasCalc=0;
	for (i=1;i<=numPredicados;i++){
		totalAristasCalc+=treps[i]->numberOfEdges;
	}
	fprintf(stderr,"numero de aristas:%d\n",totalAristasCalc);
	fprintf(stderr,"TAM SUBM:%d\n",treps[1]->tamSubm);
	long fin=getMemoria();
	fprintf(stderr,"%ld bytes\n",fin-ini);
	int results=0;
	int errores = 0;
	
	gettimeofday(&tv1, NULL);
	startClock();
	int m;
	//for (m=0;m<100;m++)
	for (i = 0; i < numQueries; i++) {
	  for (k=0;k<numIteraciones;k++){
		switch (tipoQuery) {
		case 1:
			results = spo(treps, numPredicados, queriesDat[0][i] - 1,
					queriesDat[1][i], queriesDat[2][i] - 1);
			break;
		case 2:
			results = sp(treps, numPredicados, queriesDat[0][i] - 1,
					queriesDat[1][i]);
			break;
		case 3:
			results = po(treps, numPredicados, queriesDat[1][i],
					queriesDat[2][i] - 1);
			break;
		case 41:
			results = so(treps, numPredicados, queriesDat[0][i] - 1,
					queriesDat[2][i] - 1);
			break;
		case 42:
			results = soIndex(treps, *indiceSP, queriesDat[0][i] - 1,
					queriesDat[2][i] - 1);
			break;
		case 43:
			results =soDobleIndex(treps,*indiceSP,*indiceOP,queriesDat[0][i]-1,queriesDat[2][i]-1);
			break;
		case 51:
			results = s(treps, numPredicados, queriesDat[0][i] - 1);
			break;
		case 52:
			results = sIndex(treps, *indiceSP, queriesDat[0][i] - 1);
			break;
		case 6:
			results = pOrdenado(treps, numPredicados, queriesDat[1][i]);
			break;
		case 71:
			results = o(treps, numPredicados, queriesDat[2][i] - 1);
			break;
		case 72:
			results = oIndex(treps, *indiceOP, queriesDat[2][i] - 1);
			break;
		default:
			fprintf(stderr, "error\n");
		}

		if (DEBUG2) {
			if (results != queriesDat[3][i]) {
				errores++;
				//fprintf(stderr, "(%d)resultados:%d-reales:%d\n",i, results,
				//		queriesDat[3][i]);
			}
		}
	}
	}
	
	gettimeofday(&tv2, NULL);
	stopClock();
	printTime();
	fprintf(
					stderr,
					"Tiempo total: %ld en us\n",
					(tv2.tv_sec - tv1.tv_sec) * 1000000
							+ (tv2.tv_usec - tv1.tv_usec));

	if (DEBUG2) {
		if (!errores)
			fprintf(stderr, "TEST:OK(%d)\n", numQueries);
		else
			fprintf(stderr, "TEST:FAIL:%d/%d\n", errores, numQueries);
	}
	return 0;
}

