#ifndef ___COMMONS
#define ___COMMONS

//i->version para indices SP y OP
//sin i->version para k2-trees
#include "kTreeAux.h"
#include "directcodesI.h"
#include "merge.h"
#include "basic.h"
#include <time.h>
#define DEBUG 0
#define DEBUG2 1
//#define MAX_INFO 2294967295
#define MAX_INFO 1024*1024*50
#define PORSUJETO 1
#define POROBJETO 2
#define NUM_ELEMENTOS 20000000 //1024*1024*60
//#define NUM_ELEMENTOS 2294967295

typedef struct indiceDAC {
	uint * predicados;
	uint bitsPred;
	uint * indicePredicados;
	uint bitsIndex;
	FTRepI * dac;
} INDICEDAC;

typedef struct resultado {
	int * predicados;
	int numeroPredicados;
} RESULTADODAC;

extern Result2 ** vectores;

extern Result2 ** vectores2;

extern RESULTADODAC resDAC;

extern RESULTADODAC resDAC2;

extern int numeroSO;

int obtenerPredicados(INDICEDAC dac, int indice);

int obtenerPredicados2(INDICEDAC dac, int indice);

INDICEDAC * cargarDAC(char * baseFich, int numPredicados);

void inicializarEstructuras(int numPreds, int numSO);

void liberarMerge();

void liberarMerge2();

void startClock();

void stopClock();

void printTime();

#endif
