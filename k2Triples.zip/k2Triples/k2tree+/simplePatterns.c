#include "simplePatterns.h"
#include "commons.h"

int spo(TREP ** treps, int nPreds, int s, int p, int o) {

	if (DEBUG) {
		fprintf(stdout, "<%d,%d,%d>\n", s + 1, p, o + 1);
	}
	if (compactTreeCheckLinkQuery(treps[p], s, o))

	{
		if (DEBUG)
			fprintf(stdout, "1\n");
		return 1;
	} else {
		if (DEBUG)
			fprintf(stdout, "0\n");
		return 0;
	}

}

int so(TREP ** treps, int nPreds, int s, int o) {
	int i, resultados = 0;

	if (DEBUG)
		fprintf(stdout, "<%d,?,%d>\n", s + 1, o + 1);
	for (i = 1; i <= nPreds; i++) {
		if (compactTreeCheckLinkQuery(treps[i], s, o)) {
			if (DEBUG)
				fprintf(stdout, "<%d,%d,%d>\n", s + 1, i, o + 1);
			resultados++;
		}
	}

	return resultados;
}

int soIndex(TREP ** treps, INDICEDAC dac, int s, int o) {
	int i, resultados = 0;
	if (DEBUG)
		fprintf(stdout, "<%d,?,%d>\n", s + 1, o + 1);

	obtenerPredicados(dac, s);

	for (i = 0; i < resDAC.numeroPredicados; i++) {
		if (compactTreeCheckLinkQuery(treps[resDAC.predicados[i]], s, o)) {
			resultados++;
			if (DEBUG)
				fprintf(stdout, "<%d,%d,%d>\n", s + 1, resDAC.predicados[i],
						o + 1);
		}
	}
	return resultados;
}

int soDobleIndex(TREP ** treps, INDICEDAC dac,INDICEDAC dac2, int s, int o) {
	int  resultados = 0;

	if (DEBUG)
		fprintf(stdout, "<%d,?,%d>\n", s + 1, o + 1);
	obtenerPredicados(dac, s);
	obtenerPredicados2(dac2,o);
	int i=0,j=0;

	while (i<resDAC.numeroPredicados && j<resDAC2.numeroPredicados){
		//Dado que las ristras de predicados de SP y OP están ordenadas por predicado
		if (resDAC.predicados[i]>resDAC2.predicados[j]){
			j++;
		}
		else if (resDAC.predicados[i]<resDAC2.predicados[j]){
			i++;
		}
		else {
			if (compactTreeCheckLinkQuery(treps[resDAC.predicados[i]],s,o)){
				if (DEBUG)
					fprintf(stdout, "<%d,%d,%d>\n", s + 1, resDAC.predicados[i],o + 1);
				resultados++;
				//i++;
				//j++;
			}
			i++;
			j++;
		}
	}
	
	return resultados;
}


int sp(TREP ** treps, int nPreds, int s, int p) {
	int i;
	uint * x = infoTOTAL[0];
	int resultados;

	if (DEBUG)
		fprintf(stdout, "<%d,%d,?>\n", s + 1, p);

	resultados = compactTreeAdjacencyList(treps[p], s, x);

	if (DEBUG)
		for (i = 0; i < x[0]; i++) {
			fprintf(stdout, "<%d,%d,%d>\n", s + 1, p, x[i + 1] + 1);
		}

	return x[0];
}

int po(TREP ** treps, int nPreds, int p, int o) {
	int i;
	int resultados;
	uint * x = infoTOTAL[0];

	if (DEBUG)
		fprintf(stdout, "<?,%d,%d>\n", p, o + 1);

	resultados = compactTreeInverseList(treps[p], o, x);

	if (DEBUG)
		for (i = 0; i < x[0]; i++) {
			fprintf(stdout, "<%d,%d,%d>", x[i + 1] + 1, p, o + 1);
		}
	return x[0];
}

int s(TREP ** treps, int nPreds, int s) {
	int i, j;
	uint * x = infoTOTAL[0];
	int resultados = 0;

	if (DEBUG)
		fprintf(stdout, "<%d,?,?>\n", s + 1);


	for (i = 1; i <= nPreds; i++) {
		resultados += compactTreeAdjacencyList(treps[i], s, x);
		if (DEBUG) {
			for (j = 0; j < x[0]; j++)
				fprintf(stdout, "<%d,%d,%d>\n", s + 1, i, x[j + 1] + 1);
		}
	}
	return resultados;
}

int sIndex(TREP ** treps, INDICEDAC dac, int s) {
	uint * x = infoTOTAL[0];
	if (DEBUG)
		fprintf(stdout, "<%d,?,?>\n", s + 1);

	int cont = 0, i, j;
	obtenerPredicados(dac, s);
	for (i = 0; i < resDAC.numeroPredicados; i++) {
		compactTreeAdjacencyList(treps[resDAC.predicados[i]], s, x);
		for (j = 1; j <= x[0]; j++) {
			if (DEBUG) {
				fprintf(stdout, "<%d,%d,%d>\n", s+1, i, x[j]+1);
			}
			cont++;
		}
	}
	return cont;
}

int p(TREP ** treps, int nPreds, int p) {
	int i;
	SET * pares=paresBuff1;
	if (DEBUG)
		fprintf(stdout, "<?,%d,?>\n", p);

	compactTreeRangeQuery(treps[p], 0,pares);

	if (DEBUG) {
		for (i = 1; i <= pares[0].x; i++) {
			fprintf(stdout, "<%d,%d,%d>\n", pares[i].x + 1, p, pares[i].y + 1);
		}
	}
	return pares[0].x;

}

int pOrdenado(TREP ** treps, int nPreds, int p) {
	int i;

	if (DEBUG)
		fprintf(stdout, "<?,%d,?>\n", p);

	SET * pares=paresBuff1;
	compactTreeRangeQuery(treps[p], 1,pares);

	if (DEBUG) {
		for (i = 1; i <= pares[0].x; i++) {
			fprintf(stdout, "<%d,%d,%d>\n", pares[i].x + 1, p, pares[i].y + 1);
		}
	}

	return pares[0].x;

}

int o(TREP ** treps, int nPreds, int o) {
	int i, j;
	uint * x = infoTOTAL[0];
	int cont = 0;

	if (DEBUG)
		fprintf(stdout, "<?,?,%d>\n", o + 1);

	for (i = 1; i <= nPreds; i++) {
		cont += compactTreeInverseList(treps[i], o, x);

		if (DEBUG)
			for (j = 0; j < x[0]; j++)
				fprintf(stdout, "<%d,%d,%d>", x[j + 1] + 1, i, o + 1);
	}
	return cont;
}

int oIndex(TREP ** treps, INDICEDAC dac, int o) {
	int i, j;
	uint * x = infoTOTAL[0];
	if (DEBUG)
		fprintf(stdout, "<?,?,%d>\n", o + 1);

	int cont = 0;

	obtenerPredicados(dac, o);

	for (i = 0; i < resDAC.numeroPredicados; i++) {
		compactTreeInverseList(treps[resDAC.predicados[i]], o, x);
		for (j = 0; j < x[0]; j++) {
			cont++;
			if (DEBUG) {
				fprintf(stdout, "<%d,%d,%d>", x[j + 1] + 1, i, o + 1);
			}
		}

	}

	return cont;

}

