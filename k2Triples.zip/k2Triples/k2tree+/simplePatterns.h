#ifndef ___SIMPLEPATTERNS
#define ___SIMPLEPATTERNS

#include "kTree.h"
#include "commons.h"


int spo(TREP ** treps,int nPreds,int s,int p,int o);

int so(TREP ** treps, int nPreds, int s,int o);

int soIndex(TREP ** treps, INDICEDAC dac, int s,int o);

int soDobleIndex(TREP ** treps, INDICEDAC dac,INDICEDAC dac2, int s, int o);
	
int sp(TREP ** treps,int nPreds, int s,int p);

int po(TREP ** treps, int nPreds,int p,int o);

int s(TREP ** treps,int nPreds, int s);

int sIndex(TREP ** treps,INDICEDAC dac, int s);

int p(TREP ** treps,int nPreds, int p);

int o(TREP ** treps,int nPreds,int o);

int oIndex(TREP ** treps,INDICEDAC dac,int o);

int pOrdenado(TREP ** treps, int nPreds, int p);
	
int propagarSP(TREP ** treps, INDICEDAC dac, int s,int p);	
#endif
