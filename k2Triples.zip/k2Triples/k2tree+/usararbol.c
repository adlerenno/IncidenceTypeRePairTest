#include <stdio.h>
#include <math.h>
#include <string.h>
#include "kTree.h"
#include <sys/time.h>
#include <time.h>
#include "directcodesI.h"
#include "commons.h"
#include "simplePatterns.h"
#define SEC_TIME_DIVIDER  ((double) 1.0    )     //1 sec = 1 sec
#define SEC_TIME_UNIT       "sec"


/*****************************************/  //@@fari


unsigned long getIndexSize(tipoQuery, Index_size_sp_op, Index_size);
void alighnnum(char *str, int len);

double getTime (void)   
{
	double usertime, systime;
	struct rusage usage;

	getrusage (RUSAGE_SELF, &usage);
	usertime = (double) usage.ru_utime.tv_sec * 1000000.0 +
		(double) usage.ru_utime.tv_usec ;
	systime = (double) usage.ru_stime.tv_sec * 1000000.0 +
		(double) usage.ru_stime.tv_usec;
	//return (usertime + systime);
	return (usertime );
}   //@@fari


#define LOGTIMES
/**/ FILE *gnuFile;
/**/ char operation[10];
/**/ char *indexbasename;
ulong Index_size=0;
ulong Index_size_sp_op=0;
/*****************************************/ //@@fari



int main(int argc, char* argv[]) {
	int i,k;
	struct timeval tv1, tv2;
	FILE * queries;
	int * queriesDat[4];
	int tipoQuery;

	if (argc < 9) {
		fprintf(
				stderr,
				"USAGE: %s <GRAPH> <nPred> <queries> <nQueries> <dacCodeS> <dacCodeO> <|SO|> <tipoQuery> [iter]\n",
				argv[0]);
		return (-1);
	}

	printf("\n\n### loading structs ##########\n");fflush(stdout);
	inicializaMemoria();

	int numSO=atoi(argv[7]);
	tipoQuery = atoi(argv[8]);
	int numPredicados = atoi(argv[2]);
	int numQueries = atoi(argv[4]);
	fprintf(stderr,"numpredicados: %d\n",numPredicados);
	fprintf(stderr,"num queries:%d\n",numQueries);
	int numIteraciones=1;

	if (argc==10){
		numIteraciones=atoi(argv[9]);
		fprintf(stderr,"Iteraciones:%d\n",numIteraciones);
	}
	else numIteraciones=1;
	fprintf(stderr,"Indice SP:\n");	
	long memoriaAntes=getMemoria();
	INDICEDAC * indiceSP = cargarDAC(argv[5],numPredicados);
	long memoriaDespues=getMemoria();
	fprintf(stderr,"%ld bytes\n",memoriaDespues-memoriaAntes);
	
	Index_size_sp_op = memoriaDespues-memoriaAntes;
	
	memoriaAntes=memoriaDespues;
	fprintf(stderr,"Indice OP\n");
	INDICEDAC * indiceOP = cargarDAC(argv[6],numPredicados);
	memoriaDespues=getMemoria();
	fprintf(stderr,"%ld bytes\n",memoriaDespues-memoriaAntes);
	
	Index_size_sp_op += memoriaDespues-memoriaAntes;
	
	inicializarEstructuras(numPredicados, numSO);
	
	int numS=0;
	long acumulacion=0;
	/*for (numS=0;numS<65200769;numS++){
	  obtenerPredicados(*indiceOP,numS);
	  acumulacion+=resDAC.numeroPredicados;
	}*/

	for (i = 0; i < 4; i++) {
		queriesDat[i] = (int *) malloc(sizeof(int) * numQueries);
	}

	if ((queries = fopen(argv[3], "r")) == NULL) {
		fprintf(stderr, "error: no se pudo abrir el fichero %s\n", argv[3]);
		return 1;
	} else {
		fprintf(stderr, "%s\n", argv[3]);
	}


	
	for (i = 0; i < numQueries; i++){
		if (-1==fscanf(queries,"%d;%d;%d;%d\n",  &queriesDat[0][i],&queriesDat[1][i],
				&queriesDat[2][i],&queriesDat[3][i])){
			fprintf(stderr,"error al leer queries\n");exit(1);
		}
	}

	TREP ** treps = (TREP **) mymalloc(sizeof(TREP *) * (numPredicados+1));

	char nomFich[256];

	fflush(stdout);fflush(stderr);
	fprintf(stderr,"Predicados\n");
	fflush(stdout);fflush(stderr);

	long ini=getMemoria();
	for (i = 1; i <= numPredicados; i++) {
		
	//	if (!(i%100))fprintf(stderr,"%d\n",i);
		sprintf(nomFich, "%s%d.txt", argv[1], i);
		treps[i] = loadTreeRepresentation(nomFich);
	}

	int totalAristasCalc=0;
	for (i=1;i<=numPredicados;i++){
		totalAristasCalc+=treps[i]->numberOfEdges;
	}
	fprintf(stderr,"numero de aristas:%d\n",totalAristasCalc);
	fprintf(stderr,"TAM SUBM:%d\n",treps[1]->tamSubm);
	long fin=getMemoria();
	fprintf(stderr,"%ld bytes\n",fin-ini);

	Index_size = fin-ini;



	Index_size = getIndexSize(tipoQuery, Index_size_sp_op, Index_size); //depending on using idx or not
	


	#ifdef LOGTIMES  //@@fari
	indexbasename = argv[1];
	/**/    int queryType =tipoQuery;
	/**/	char outFilenameGNU[256];	
	/**/	switch(queryType) {
	/**/	case 1  : { sprintf(operation,"spo"); break;}
	/**/	case 2  : { sprintf(operation,"spV"); break;}
	/**/	case 3  : { sprintf(operation,"Vpo"); break;}
	/**/	case 41 : 
	/**/	case 42 : 
	/**/	case 43 : { sprintf(operation,"sVo"); break;}
	/**/	case 51 : 
	/**/	case 52 : { sprintf(operation,"sVV"); break;}
	/**/	case 6  : { sprintf(operation,"VpV"); break;}
	/**/	case 71 : 
	/**/	case 72 : { sprintf(operation,"VVo"); break;}
	/**/}
	/**/	sprintf(outFilenameGNU,"%s.dat",operation);
	/**/	struct stat bufgnu;
	/**/	if (-1 == stat(outFilenameGNU, &bufgnu)){
	/**/		gnuFile =fopen(outFilenameGNU,"w");
	/**/		if (!gnuFile) {printf("\n could not open GNUPLOT data file (%s)... exitting\n",outFilenameGNU); exit(0);}
	/**/		fprintf(gnuFile,"#%15s\t%15s\t%15s\t%15s\t%15s\t%3s\t%8s\t%s\n","IdxSize(byte)","usec/pat","usec/occ","occs","numpats", "#oper", "#repeats","#indexBaseName");
	/**/	}
	/**/	else {
	/**/		gnuFile = fopen(outFilenameGNU,"a");
	/**/		if (!gnuFile) {printf("\n could not open GNUPLOT data file (%s)... exitting\n",outFilenameGNU); exit(0);}
	/**/	}
	#endif	


	int results=0;
	int totalresults=0;
	int errores = 0;
	
	/***************************************/

	printf("\n\n### starting search: %d queries, %d iters  ##########\n", numQueries, numIteraciones);fflush(stdout);

	gettimeofday(&tv1, NULL);
	startClock();
	int m;

	double time1 = getTime();  //@@fari

	//for (m=0;m<100;m++)
  for (k=0;k<numIteraciones;k++){
	totalresults=0;

	for (i = 0; i < numQueries; i++) {
		switch (tipoQuery) {
		case 1:
			results = spo(treps, numPredicados, queriesDat[0][i] - 1,
					queriesDat[1][i], queriesDat[2][i] - 1);
			break;
		case 2:
			results = sp(treps, numPredicados, queriesDat[0][i] - 1,
					queriesDat[1][i]);
			break;
		case 3:
			results = po(treps, numPredicados, queriesDat[1][i],
					queriesDat[2][i] - 1);
			break;
		case 41:
			results = so(treps, numPredicados, queriesDat[0][i] - 1,
					queriesDat[2][i] - 1);
			break;
		case 42:
			results = soIndex(treps, *indiceSP, queriesDat[0][i] - 1,
					queriesDat[2][i] - 1);
			break;
		case 43:
			results =soDobleIndex(treps,*indiceSP,*indiceOP,queriesDat[0][i]-1,queriesDat[2][i]-1);
			break;
		case 51:
			results = s(treps, numPredicados, queriesDat[0][i] - 1);
			break;
		case 52:
			results = sIndex(treps, *indiceSP, queriesDat[0][i] - 1);
			break;
		case 6:
			results = pOrdenado(treps, numPredicados, queriesDat[1][i]);
			break;
		case 71:
			results = o(treps, numPredicados, queriesDat[2][i] - 1);
			break;
		case 72:
			results = oIndex(treps, *indiceOP, queriesDat[2][i] - 1);
			break;
		default:
			fprintf(stderr, "error\n");
		}
		totalresults +=results;

		if (DEBUG2) {
			if (results != queriesDat[3][i]) {
				errores++;
				//fprintf(stderr, "(%d)resultados:%d-reales:%d\n",i, results,
				//		queriesDat[3][i]);
			}
		}
	}
  }
	
	double totalTime = (getTime() - time1);  //@@fari

	gettimeofday(&tv2, NULL);
	stopClock();

	printTime();
	fprintf(
					stderr,
					"Tiempo total: %ld en us\n",
					(tv2.tv_sec - tv1.tv_sec) * 1000000
							+ (tv2.tv_usec - tv1.tv_usec));
							
							

	if (DEBUG2) {
		if (!errores)
			fprintf(stderr, "TEST:OK(%d)\n", numQueries);
		else
			fprintf(stderr, "TEST:FAIL:%d/%d\n", errores, numQueries);
	}



//@@fari

	printf("\n TIEMPO FARI :    Operacion = %s",operation);
	printf("\n TIEMPO FARI :    numQueries = %d, numIters = %d",numQueries,numIteraciones );
	printf("\n TIEMPO FARI : T en microsec = %2.8f (per iter) ",totalTime/numIteraciones);
	printf("\n TIEMPO FARI :         noccs = %d",totalresults);
	printf("\n TIEMPO FARI :  microsec/occ = %2.6f",totalTime/numIteraciones/totalresults);
	printf("\n TIEMPO FARI :  microsec/pat = %2.6f",totalTime/numIteraciones/numQueries);
//@@fari


		#ifdef LOGTIMES
		/**/    char timeperpat[50]=""; sprintf(timeperpat,"%5.9f", totalTime/numIteraciones/numQueries );
		/**/    char timeperocc[50]=""; sprintf(timeperocc,"%5.9f", totalTime/numIteraciones/totalresults);
		/**/	alighnnum(timeperpat,15);alighnnum(timeperocc,15);
		/**/	fprintf(gnuFile," %15ld\t",Index_size);
		/**/	fprintf(gnuFile,"%15s\t",timeperpat);
		/**/	fprintf(gnuFile,"%15s\t",timeperocc);
		/**/	fprintf(gnuFile,"%15lu\t",(ulong)totalresults);
		/**/	fprintf(gnuFile,"%15u\t",numQueries);
		/**/	fprintf(gnuFile,"#%3s\t",operation);
		/**/	fprintf(gnuFile,"#%7d\t",numIteraciones);
		/**/	fprintf(gnuFile,"#%s\n",indexbasename);
		
		fclose(gnuFile);
		#endif

	return 0;
}















unsigned long getIndexSize(tipoQuery, Index_size_sp_op, Index_size) {
switch (tipoQuery) {
		case 1:  //spo
			return Index_size;
		case 2:  //sp?
			return Index_size;
		case 3:  //?po
			return Index_size;
		case 41: //s?o
			return Index_size;
		case 42: //s?o
			return 0;// NO USAR: Index_size_sp_op + Index_size;
		case 43: //s?o
			return Index_size_sp_op + Index_size;
		case 51: //s??			
			return Index_size;
		case 52: //s??			
			return Index_size_sp_op + Index_size;
		case 6:  //?p?						
			return Index_size;
		case 71: //??o						
			return  Index_size;
		case 72: //??o	
			return Index_size_sp_op + Index_size;
		default:
			return 0; 
		}	
}



/* used for gnuplot formatting file */
void alighnnum(char *str, int len){
	int n=strlen(str);
	int i;
	if (n<len) {
	  int shift = len-n;
	  for (i=len-1; i>=shift;i--)
		 str[i] = str[i-shift];
	  for (i=0;i<shift;i++) str[i]=' ';
	  
//for (i=0;i< len-n;i++)
//		str[i+n]=' ';
//
//	  for (i=0;i< len-n;i++)
//		str[i+n]=' ';
//	  str[len]='\0';
	}
}
