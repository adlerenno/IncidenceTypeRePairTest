/*
 * prueba2.c
 *
 *  Created on: Nov 29, 2012
 *      Author: sandra
 */




