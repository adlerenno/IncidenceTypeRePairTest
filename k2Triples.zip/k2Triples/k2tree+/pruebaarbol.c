#include <stdio.h>
#include <math.h>
#include <string.h>
#include "kTree.h"

int main(int argc, char* argv[]) {
	FILE *f;
	uint nodes;
	uint edges;
	register uint i;

	if (argc < 6) {
		fprintf(stderr,
				"USAGE: %s <GRAPH> <node> <name> <K1> <K2> [<max level K1>]\n",
				argv[0]);
		return (-1);
	}

	//char *filename = (char *)malloc(sizeof(char)*20);

	f = fopen(argv[1], "r");
	fread(&nodes, sizeof(uint), 1, f);

	//nodes = 11;
	//nodes = 40;
	int _K1 = atoi(argv[4]);
	int _K2 = atoi(argv[5]);

	uint tamSubm = 1 << 22;//177147; //3^11
	uint part;
	part = nodes / tamSubm + 1;

	uint nodesOrig = nodes;
	nodes = tamSubm;

	//printf("nodos: %d, K1: %d K2: %d\n",nodes,_K1,_K2);

	int max_level1;
	int max_real_level1;
	max_real_level1 = ceil(log(nodes) / log(_K1)) - 1;
	if (argc < 7)
		max_level1 = ceil(log(nodes) / log(_K1)) - 1;
	else
		max_level1 = atoi(argv[6]);
	//printf("nodos: %d, maximo nivel1: %d max real 1: %d\n",nodes,max_level1,max_real_level1);

	int nodes2 = 1;
	for (i = 0; i < max_real_level1 + 1; i++) {
		nodes2 *= _K1;
	}
	//fprintf(stderr,"nodes2 %d\n",nodes2);


	for (i = 0; i < max_level1; i++)
		nodes2 = ceil((double) nodes2 / _K1);
	//fprintf(stderr,"nodes2 %d\n",nodes2);


	int max_level2 = ceil(log(nodes2) / log(_K2)) - 1;
	//printf("nodos: %d, maximo nivel1: %d max real 1: %d maximo nivel2: %d opr: %d\n",nodes,max_level1,max_real_level1,max_level2,nodes2);


	fread(&edges, sizeof(uint), 1, f);
	//printf("aristas: %d\n",edges);

	//edges = 12;
	//edges = 101;
	uint nodes_read = 0;

	uint algo;
	ulong algo2;
	int id1, id2;
	NODE * tree;
	MREP * rep;
	TREP * trep;
	int fila, columna;

	trep = createTreeRep(nodesOrig, edges, part, tamSubm, max_real_level1,
			max_level1, max_level2, _K1, _K2);
	fclose(f);
	uint edges_read = 0;
	for (fila = 0; fila < part; fila++) {

		for (columna = 0; columna < part; columna++) {
			uint edges_sub = 0;

			numberNodes = 0;
			numberLeaves = 0;
			numberTotalLeaves = 0;

			fprintf(stderr, "(%2.2f\%)\n", (float) (fila * part + columna)
					* 100 / part / part);
			f = fopen(argv[1], "r");

			fread(&algo, sizeof(uint), 1, f);
			fread(&algo, sizeof(uint), 1, f);

			tree = createKTree(_K1, _K2, max_real_level1, max_level1,
					max_level2);

			nodes_read = 0;
			edges_read = 0;

			for (i = 0; i < nodesOrig + edges; i++) {
				//fprintf(stderr,"---i: %d, limite: %d\n",i,nodes+edges);
				int k;
				fread(&k, sizeof(uint), 1, f);
				if (k < 0) {
					//	fprintf(stderr,"Nodo nuevo: %d, nodos %d hojas %d\n",nodes_read, numberNodes, numberLeaves);
					nodes_read;
				} else {
					k--;
					//if(k<40){
					//fprintf(stderr,"Introduciendo %d %d\n",nodes_read-1,k);


					id1 = nodes_read - 1;
					id2 = k;

					if ((id1 >= fila * tamSubm) && (id1 < (fila + 1) * tamSubm)
							&& (id2 >= columna * tamSubm) && (id2 < (columna
							+ 1) * tamSubm)) {

						insertNode(tree, id1 - fila * tamSubm, id2 - columna
								* tamSubm);
						edges_sub++;
					}
					edges_read++;
				}
			}
			fclose(f);

			MREP * rep;
			rep = createRepresentation(tree, nodes, edges_sub);
			insertIntoTreeRep(trep, rep, fila, columna);
		}
	}

	compressInformationLeaves(trep);
	uint * listady=infoTOTAL[0];
	compactTreeAdjacencyList(trep, atoi(argv[2]),listady);
	//fprintf(stderr,"llego\n");
	fprintf(stderr, "Number of neighbours: %d\n", listady[0]);
	for (i = 0; i < listady[0]; i++)
		fprintf(stderr, "%d\n", listady[i + 1]);
	//fprintf(stderr,"\n");
	saveTreeRep(trep, argv[3]);
	destroyTreeRepresentation(trep);
	return 0;
}

