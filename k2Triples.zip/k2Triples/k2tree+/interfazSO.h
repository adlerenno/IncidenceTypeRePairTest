#ifndef ___INTERFAZSO
#define ___INTERFAZSO
#include <stdio.h>
#include "kTree.h"
#include "commons.h"


/* EVALUACIÓN EN CADENA: OPERACIONES BÁSICAS *///man: serielle varianten
extern inline int compactNeighbour(TREP * trep, int y, uint * resultados, int parte);

extern inline int compactNeighbourOpposite(TREP * trep, int y, uint * resultados, int parte);

extern inline int compactNeighbourMerge(TREP * trep,int x, Result2 **  vectores, int indiceVector, int predicado, int parte);

extern inline int compactLink(TREP * trep, int x, int y, int parte);

extern inline int obtenerPar(SET par,int parte);

extern inline int obtenerOppositePar(SET par,int parte);

// dac
extern inline int commonObtenerPredicados(INDICEDAC sp, INDICEDAC op, int indice, int parte);

extern inline int commonObtenerPredicados2(INDICEDAC sp, INDICEDAC op, int indice, int parte);



/* EVALUACIÓN EN PARALELO *///man: parallele varianten
extern inline MREP * obtenerRep(TREP * trep, int x, int y, int parte);

extern inline int getNode(int K,int i,int div_level,int indexRel,int parteDer);

extern inline int getNodeXY(int K, int x, int y, int indexRel, int parteDer);

extern inline void commonAddItem2(TREP * trepIndex, int rankValue, int i,
		int div_level, int indexRel, int flag, int parte);

extern inline void CommonInitItemJoin2(TREP * trepIndex, int elem,int x,int y, int pred, int flag,int parte);

extern inline void CommonInitItemJoin(TREP * trepIndex, int elem,int x,int y, int pred,int parte);

extern inline void commonAddItem(TREP * trepIndex, int rankValue, int i, int div_level, int indexRel,
		 int parte);

extern inline void commonAddItemXY(TREP * trepIndex, int rankValue, int x,int y, int div_level, int indexRel,
		int parte);

extern inline void commonAddItemXY2(TREP * trepIndex, int rankValue, int x,int y, int div_level, int indexRel,
		int flag,int parte);

extern inline int getPosRel(int i,int x,int K, int parteDer);

extern inline int getPosRelXY(int x, int y, int K, int parteDer);

extern inline int getPosAbs(int K, int i, int j, int indexRel,int indiceRel, int tamSubm, int parte);

extern inline int getPosAbs2(int K, int i, int j, int indexRel, int indiceRel, int tamSubm, int parte);

extern inline int elegirDimension(int i,int j,int parte);

/* DEBUG */
extern void printTripleta(int x,int y,int z,int parte);


#endif
