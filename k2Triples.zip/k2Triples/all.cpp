/*
This Programm should merge all other Programs into one. The subprogram should be called via a flag.
*/
#ifdef __STDC_ALLOC_LIB__
#define __STDC_WANT_LIB_EXT2__ 1
#else
#define _POSIX_C_SOURCE 200809L
#endif
extern "C" {
#include "tte/triplestok2e.h"
#include "k2tree/pruebaarbol.h"
#include "k2tree/recuperararbol.h"
#include "k2tree/recuperarinverso.h"
#include "k2tree/tiemposarbol.h"
#include "k2tree/usararbol.h"
#include "k2tree/tiemposinverso.h"
}
#include "tti/querry_translate.hpp"
#include "tti/indexmake.hpp"
#include <unordered_map>
#include <string>
#include "iostream"
#include <chrono>
#include <thread>
#include <vector>
#include "iterator"
#include <cstring>
#include <unistd.h>
#include <iostream>
#include <sstream>
#include <fstream>
#include <random>
#include <list>
#include <set>

int main(int argc, char* argv[]){
    if (argc<2)
    {
        std::cout << "Error Expected subprogramm indicator as first argumentn";
        return-1;
    }
    int index;
    std::unordered_map<std::string, int>mapto;
    mapto["--help"]=0; mapto["-h"]=0;               // Help
    mapto["-b"]=1; mapto["--build"]=1;              // Kompletter Erstellprozess in einem 
    mapto["-u"]=2; mapto["--use"]=2;                // Anfrage inclusive übersetzung  
    mapto["-rb"]=3; mapto["--rebuild_tree"]=3;      // rebuild_tree wie einzel Programm
    mapto["-irb"]=4; mapto["--invrebuild_tree"]=4;  // invrebuild_tree wie einzel Programm
    mapto["-bt"]=5; mapto["--build_tree"]=5;        // build_tree wie einzel Programm
    mapto["-ut"]=6; mapto["--use_tree"]=6;          // use_tree also Anfrage ohne Uebersetzung
    mapto["-t"]=7; mapto["--test"]=7;               // test_tree oder revtest_tree das Kommandozeilenargumente nimmt
    mapto["-ta"]=8; mapto["--test_tree"]=8;         // test_tree wie einzel Programm
    mapto["-ita"]=9; mapto["--revtest_tree"]=9;     // revtest_tree wie einzel Programm
    mapto["-tte"]=10;                               // Einzel Programm tte 
    mapto["-im"]=11; mapto["--index_make"]=11;      // Einzel Programm index_make
    mapto["-qt"]=12; mapto["--query_translate"]=12;// Einzel Programm querry_translate
    mapto["-mq"]=13;mapto["--make_query"]=13;      // Ertstellt Zufällige Anfrage Textdateien zum testen

    try
    {
        index= mapto.at(argv[1]);
    }
    catch(const std::out_of_range& e)
    {
        std::cerr <<"Error: unknown subprogram indicator\n \t check -h --help for additional information" << '\n';
        return -1;
    }
    

    switch (index)
    {
    case 0:{
        /* Here should be a Commandline output to show available funktions */
        std::cout << "Helppage:\n This program allows convenient access to the individual subprograms of the k^2\n \
        \n\
        -h --help \n\
        \t This call shows all available subfunctions and how to call them.\n\
        \n\
        Main Functions:\n\
        -b --build \n\
        \t This call builds a k^2 Triples Forest from for example a .nq or .nt File. \n\
        \t Parameters: <Inputfile> <Outputfilename> <K1> <K2> [<max level K1>]. \n\
        \t For <k1> and <k2> 4 and 2 are sensible defaults.\n\
        \n\
        -u --use\n\
        \t This call executes a List of Querys on a Tree. This is does a query_translate and use_tree call in one.\n\
        \t Parameters: <Forest> <Plaintextquerrys> <Outputfilename> <DiccP> <DiccSO> <DiccS> <DiccO> <numPraed>. \n\
        \n\
        \n\
        \n\
        \n\
        Rest:\n\
        \n\
        -t --test\n\
        \t This Testfunktion to allow calls to test_tree and revtesttree without existing files. \n\
        \t It will write given comandline arguments to a file and uses them in a (rev-)test_tree call\n\
        \t on the forest given as second argument. The first argument should be a bool on wether to use revtest_tree. \n\
        \t Since those don't seem to work this is not usefull anymore \n\
        \n\
        -rb --rebuilt_tree\n\
        \t This call is a passthrough to rebuilt_tree\n\
        \t Parameter is a single tree\n\
        \n\
        -irb --invrebuilt_tree\n\
        \t This call is a passthrough to invrebuilt_tree\n\
        \t Parameter is a single tree\n\
        \n\
        -bt --built_tree\n\
        \t This call is a passthrough to built_tree\n\
        \t Parameters: <pairfile> <node> <outname> <K1> <K2> [<max level K1>].\n\
        \t <node> should be 1 and for <k1> and <k2> 4 and 2 are sensible defaults\n\
        \n\
        -ut --use_tree\n\
        \t This call is a passthrough to use_tree\n\
        \t Parameters: <Forest> <NumPräd> <querryfile>.\n\
        \n\
        -ta --test_tree\n\
        \t This call is a passthrough to test_tree\n\
        \t Parameters are the forest and testqueryfile.\n\
        \n\
        -ita --revtest_tree\n\
        \t This call is a passthrough to revtest_tree.\n\
        \t Parameters are the forest and testqueryfile.\n\
        \n\
        -tte\n\
        \t This call is a passthrough to tte,\n\
        \t Parameters are the Path of the .hdt.triples file to translate and the outputname.\n\
        \n\
        -im --index_make \n\
        \t This program written by me translates .nq or .nt files into the required .hdt.triples format.\n\
        \t Parameters are inputfile and outputname.\n\
        \t Preserves the indexes of Elements in outputname.Dicc(P/SO/S/O),txt files.\n\
        \n\
        -qt --query_translate \n\
        \t This call translates Querys from Text to the required Indexformat.\n\
        \t Textquerrys are Triples S P O separated by spaces like in the NTriples with unknowns are marked by ?. \n\
        \t Parameters: <Plaintextquerrys> <Outputfilename> <DiccP> <DiccSO> <DiccS> <DiccO>.\n\
        \n\
        -mq --make_query \n\
        \t This function is a test addon that randomly generates querys form an .nt or .nq file\n\
        \t Parameters: <Inputfile> <Outputfilename> <count> <numTriple> <Type_of_Querry>.\n\
        \t <numTriples> is the number of Triples in the input, count the number of generated querys\n\
        \t and <Type_of_Querry> is a number between 1 and 7. Compare to thesis.  \n" ;
        break;}
    case 5:{
        /*build_tree passthrough*/
        char* argv2bt[argc];
        argv2bt[0] = "build_tree";
        for (size_t i = 1; i < argc-1; i++)
        {
            argv2bt[i]=argv[i+1];
        }
        
        build_tree(argc-1,argv2bt);
        return 0;
    break;}
    case 6:{
        /*use_tree passthrough*/
        char* argv2[argc];
        argv2[0] = "use_tree";
        for (size_t i = 1; i < argc-1; i++)
        {
            argv2[i]=argv[i+1];
        }
        
        use_tree(argc-1,argv2);
        return 0;
    break;}
    case 3:{
        /*rebuild_tree passthrough*/
        char* argv2[argc];
        argv2[0] = "rebuild_tree";
        for (size_t i = 1; i < argc-1; i++)
        {
            argv2[i]=argv[i+1];
        }
        
        rebuild_tree(argc-1,argv2);
        return 0;
    break;}
    case 4:{
        /*invrebuild_tree passthrough*/
        char* argv2[argc];
        argv2[0] = "invrebuild_tree";
        for (size_t i = 1; i < argc-1; i++)
        {
            argv2[i]=argv[i+1];
        }
        
        invrebuild_tree(argc-1,argv2);
        return 0;
    break;}

    case 8:{
        /*test_tree passthrough*/
        char* argv2[argc];
        argv2[0] = "test_tree";
        for (size_t i = 1; i < argc-1; i++)
        {
            argv2[i]=argv[i+1];
        }
        
        test_tree(argc-1,argv2);
        return 0;
    break;}
    case 9:{
        /*revtest_tree passthrough*/
        char* argv2[argc];
        argv2[0] = "revtest_tree";
        for (size_t i = 1; i < argc-1; i++)
        {
            argv2[i]=argv[i+1];
        }
        
        revtest_tree(argc-1,argv2);
        return 0;
    break;}
    case 10:{
        /*tte passthrough*/
        char* argv2[argc];
        argv2[0] = "tte";
        for (size_t i = 1; i < argc-1; i++)
        {
            argv2[i]=argv[i+1];
        }
        
        tte(argc-1,argv2);
        return 0;
    break;}
    case 11:{
        /*index_make passthrough*/
        char* argv2[argc];
        argv2[0] = "index_make";
        for (size_t i = 1; i < argc-1; i++)
        {
            argv2[i]=argv[i+1];
        }
        
        indexmake(argc-1,argv2);
        return 0;
    break;}
    case 12:{
        /*querry_translate passthrough*/
        char* argv2[argc];
        argv2[0] = "querry_translate";
        for (size_t i = 1; i < argc-1; i++)
        {
            argv2[i]=argv[i+1];
        }
        
        querry_translate(argc-1,argv2);
        return 1;
    break;}
    case 1:{
        /*build argument for the entire build precess for index_make to build_tree*/
        int num_pred=0;
        if (argc<6)
        {
            std::cerr << "Erwartet: "<<argv[0]<<" "<<argv[1] <<" <Inputfile> <Outputfilename> <K1> <K2> [<max level K1>]\n";
            return -1;
        }
        for (size_t i = 0; i < 6; i++)
        {
            std::cout << argv[i]<< " ";
        }
        std::cout << "\n";
        char* input =argv[2];
        char* outname =argv[3];
        int k1 = atoi(argv[4]);
        int k2 = atoi(argv[5]);
        char* argv2[3];
        argv2[0]="index_make";
        argv2[1]=input; 
        //std::strcpy(triples, outname);
        argv2[2]=outname;
        std::cout << "Calling index with Param: "<<argv2[0]<<" " << argv2[1]<<" "<<argv2[2]<< "\n";
        indexmake(3,argv2);;
        char triples[strlen(outname)+12];
        strcpy(triples,outname);
        std::strcat(triples,".hdt.triples");
        char* argv3[3];
        argv3[0]="tte";
        argv3[1]=triples;
        argv3[2]=outname;
        sleep(5);
        std::cout << "Calling tte with Param: "<<argv3[0]<<" " << argv3[1]<<" "<<argv3[2]<< "\n";
        tte(3,argv3);
        std::cout <<"\n";
        //std::this_thread::sleep_for(std::chrono::milliseconds(2000));
        std::string line;
        std::ifstream myfile((std::string)outname+"DiccP.txt");

        while (std::getline(myfile, line)){
            ++num_pred;
        }
        std::cout << "Anzahl Präd: " << num_pred << "\n";
        if (argc>6)
        {
            char* argv4[7];
            for (size_t i = 1; i <= num_pred; i++)
            {   
                char triplepräd[100];
                std::strcpy(triplepräd,outname);
                std::strcat(triplepräd, ("-"+std::to_string(i)).c_str());
                argv4[0]="build_tree";
                argv4[1]=triplepräd;
                argv4[2]="0"; // eventuell auch 1
                argv4[3]=triplepräd;
                char cstring[100];
                std::string vier = std::to_string(k1);
                std::strcpy(cstring,vier.c_str());

                argv4[4] = cstring;
                char cstring2[100];
                std::string fuenf =std::to_string(k2);
                std::strcpy(cstring2,fuenf.c_str());
                argv4[5]=cstring2;
                argv4[6]= argv[6];
                std::cout << argv4[0]<<" "<< argv4[1]<<"  "<< argv4[2]<<" "<< argv4[3]<<"  "<< argv4[4]<<k1 <<" "<< argv4[5]<<k2<<" "<< argv4[6]<<"\n";
                build_tree(7,argv4);
            }
        }
        else
        {
            char* argv4[6];
            std::cout <<"Here6\n";
            for (size_t i = 1; i <= num_pred; i++)
            {
                char triplepräd[100];
                std::strcpy(triplepräd,outname);
                std::strcat(triplepräd, ("-"+std::to_string(i)).c_str());
                argv4[0]="build_tree";
                argv4[1]=triplepräd;
                argv4[2]="1";
                argv4[3]=triplepräd;
                char cstring[100];
                std::string vier = std::to_string(k1);
                std::strcpy(cstring,vier.c_str());

                argv4[4] = cstring;
                char cstring2[100];
                std::string fuenf =std::to_string(k2);
                std::strcpy(cstring2,fuenf.c_str());
                argv4[5]=cstring2;
                //std::cout << argv4<<"\n";
                build_tree(6,argv4);
            }
        }
        
        
        

    break;}
    case 2:{
        /*use argument for the entire use precess for querry_translate to use_tree*/
        if (argc<10)
        {
            std::cerr << "Erwartet: "<<argv[0]<<" "<<argv[1] <<" <Graph> <Plaintextquerrys> <Outputfilename> <DiccP> <DiccSO> <DiccS> <DiccO> <numPraed> \n";
            return -1;
        }
        char* querrytargs[7];
        querrytargs[0]= "querry_translate";
        querrytargs[1]= argv[3];
        querrytargs[2]= argv[4];
        querrytargs[3]= argv[5];
        querrytargs[4]= argv[6];
        querrytargs[5]= argv[7];
        querrytargs[6]= argv[8];

        querry_translate(7,querrytargs);

        char* useargs[4];
        useargs[0]="use_tree";
        useargs[1]=argv[2];
        useargs[2]=argv[9];
        useargs[3]=argv[4];

        std::cout << useargs[1] << ", "<< useargs[2]<< ", "<<useargs[3]<< "\n";
        use_tree(4,useargs);
    break;}
    case 7:{
        if (argc<5)
        {
            std::cerr << "Erwartet: "<<argv[0]<<" "<<argv[1] <<" <inv?> <PrädikatBaum> <Subjekt1|Objekt1> ...\n";
            return -1;
        }

        //build querry file
        std::string file ="test_tree_querryfile.hex";
        FILE * f =fopen(file.c_str(),"w");
        int out[argc-4+1];
        out[0]=argc-4;
        for (size_t i = 1; i <= out[0]; i++)
        {
            out[i]= atoi(argv[3+i]);
        }
    
        fwrite(out,4,argc-4+1,f);
        fclose(f);

        //build args for call
        char* testargs[3];
        testargs[0]= "test_tree";
        testargs[1]= argv[3];
        testargs[2]= "test_tree_querryfile.hex";
        
        std::cout << testargs[1]<< " "<<testargs[2] <<"\n";
        //inv or not normel
        if (atoi(argv[2]))
        {
            testargs[0]= "revtest_tree";
            revtest_tree(3,testargs);
        }else
        {
            test_tree(3,testargs);
        }
  
    break;}
    
    case 13:{
        //Soll Querry testfiles aus Datensatz erstellen.
        if (argc<6)
        {
            std::cerr << "Erwartet: "<<argv[0]<<" "<<argv[1] <<" <Inputfile> <Outputfilename> <count> <numTriple> <Type>\n";
            return -1;
        }

        std::ifstream readfile;
        readfile.open(argv[2]);

        std::ofstream outfile;
        outfile.open(argv[3]);
        std::string line;
        bool inqoute = false;
        bool wasbs =false;
        uint_fast8_t state = 0;
        std::string S = "";
        std::string P = "";
        std::string O = "";
        int next;
        std::random_device rd;
        std::mt19937 gen(rd()); 
        std::uniform_int_distribution<> distrib(1, atoi(argv[5]));
        int number =atoi(argv[4]);
        std::set<int>indexes;
        int count = 1;
        int countlist = 1;
        for (size_t j = 0; j < number;j++){
            indexes.insert(distrib(gen));
        }
        //indexes.sort();
        /*
        for (int e : indexes){
            std::cout << e <<", ";
        }
        */
        std::cout << "\n";
        outfile << number << "\n";
        //next = indexes.front();
        //indexes.pop_front();
        for (int e : indexes){
        while (std::getline(readfile, line))
        {
        if (count ==e)
        {
            //std::cout <<countlist << "\n";
            for (int i = 0; i<line.length();i++){
                if (line[i]==' '&&!inqoute){
                    //fprintf(stdout,"Here I Read %s\n","Hello");
                    state++; 
                }else{
                    if (line[i]=='"'&&!wasbs){
                        wasbs = false;
                        inqoute = !inqoute;    
                    }
                    switch(state){
                        case 0: S+=line[i]; break;
                        case 1: P+=line[i]; break;
                        case 2: O+=line[i]; break;
                    }
                    
                }
                if(line[i]=='\\' ){
                    wasbs =true;
                }else{
                    if(wasbs){
                        wasbs =false;    
                    }
                }
            }
            inqoute = false;
            if (S.empty()||O.empty()||P.empty()){
                //std::cout << S <<",, "<<O<<",, "<<P<<"\n";
                std::cout <<"PSOcount:"<<count<<"\n";
                S.clear();
                O.clear();
                P.clear();
                goto endofread;
            }
            if (S[0]== '#'){// Ignorier Kommentare 
                S.clear();
                O.clear();
                P.clear(); 
                state = 0;
                continue;
            }
            switch(atoi(argv[6])){
                case 1:
                outfile << S<<" "<<P <<" "<<O<< " \n"; 
                break;
                case 2: 
                outfile << S <<" "<<"?" <<" "<<O << "\n"; 
                break;
                case 3: 
                outfile << S <<" "<<P <<" "<<"?"  << "\n" ; 
                break;
                case 4: 
                outfile << "?"<<" "<<P <<" "<<O<< " \n"; 
                break;
                case 5: 
                outfile << "?"<<" "<<"?" <<" "<<O<< " \n"; 
                break;
                case 6: 
                outfile << "?"<<" "<<P <<" "<<"?"<< " \n"; 
                break;
                case 7: 
                outfile << S <<" "<< "?" <<" "<<"?"  << "\n"; 
                break;
                default:
                    std::cout <<"Error: Uknown Type:"<<"\n";
                break;
            }
            S.clear();
            O.clear();
            P.clear(); 
            state = 0;
            if (countlist<number)
            {
                countlist ++;
                goto nextfor;
            }else
            {
                goto endofread;
            }
        }  
        count ++;
            
    }
    nextfor:
    }
    endofread: 
    readfile.close();
    outfile.close();
    break;}
    default:
        break;
    }
    return 0;
}
