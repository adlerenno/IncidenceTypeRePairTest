/* Headerfile to make /tte a objekt so i can merge all Programms
*/
#pragma once
int tte(int argc, char* argv[]);