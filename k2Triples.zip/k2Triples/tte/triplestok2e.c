#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "triplestok2e.h"
typedef unsigned int uint; // added by man

int main0(int argc, char ** argv) {

    if (argc != 3) {
        printf("Use: %s <input> <output>\n", argv[0]);
        exit(1);
    }

    FILE * in = fopen (argv[1], "rb");

    unsigned long MAX = 1000000000L;

    void* ptr = calloc(MAX*3,sizeof(uint));
    uint *triples = (uint *) ptr;
    long l = fread(triples, 3*sizeof(uint), MAX, in);
    int nt = l;
    printf("Got l = %ld, nt = %d\n", l, nt);
    fflush(stdout);
    fclose(in); //threw errors
    
    
    int ns=0, np=0, no=0;
    int t;
    int s, p, o; 
    for (t = 0; t < nt; t++) {
        p = triples[3*t];
        s = triples[3*t+1];
        o = triples[3*t+2];      
        if (s > ns) ns = s;
        if (p > np) np = p;
        if (o > no) no = o;
    }

    printf("got %d %d %d s,p,o\n", ns, np, no);
    uint * counts = (uint *) malloc(np * sizeof(uint));
    uint * curc = (uint *) malloc(np * sizeof(uint));
    FILE ** files = (FILE **) malloc(np * sizeof(FILE *));
    int i;
    for (i = 0; i < np; i++) {
        counts[i] = 0;
        curc[i] = 0;
    }
    for (t = 0; t < nt; t++) {
        p = triples[3*t];
        counts[p-1]++;
    }
    printf("processed countsi; separating triples...\n");
    
    
    uint ** triplesp = (uint **) malloc(np * sizeof(uint *));
    for (i = 0; i < np; i++) {
        triplesp[i] = (uint *) malloc(2*counts[i]*sizeof(uint));
    }
    for (t = 0; t < nt; t++) {
        int ss;
        p = triples[3*t];
        s = triples[3*t+1];
        o = triples[3*t+2];      
        int offset = curc[p-1];
        triplesp[p-1][2*offset] = s;
        triplesp[p-1][2*offset+1] = o;
        curc[p-1]++; 
    } 

    free(triples);
    printf("triples separated; processing predicates...\n");
    int nnodes = no;
    printf("no: %d\n",no);
    printf("ns: %d\n",ns);
    if (nnodes < ns) {
        nnodes = ns;
    }
    char * outfilename = (char *) malloc(2048);
    FILE * out;
    for (i = 0; i < np; i++) {
        sprintf(outfilename, "%s-%d", argv[2], i+1);
        out = fopen(outfilename, "wb+");
        fwrite(&nnodes, sizeof(uint), 1, out);
        fwrite(&(counts[i]), sizeof(uint), 1, out);
        for (t = 0; t < counts[i]; t++) {
            fwrite(&(triplesp[i][2*t]), sizeof(uint), 1, out);
            fwrite(&(triplesp[i][2*t+1]), sizeof(uint), 1, out);
        }
        fclose(out);
        printf("%d ", i);fflush(stdout);
    }
    return 0;
    //exit(0); // old: does not work
}
int tte(int argc, char *argv[])
{
    return main0(argc, argv);
}